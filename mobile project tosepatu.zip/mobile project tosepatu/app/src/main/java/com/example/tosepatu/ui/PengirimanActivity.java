package com.example.tosepatu.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tosepatu.R;

public class PengirimanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pengiriman_detailorder_layout);

    }
}
package com.example.tosepatu.api;


public class apiconfig {

    public static final String URL = "http://tosepatu.project-ai.online/";
    public static final String BASE_URL = URL+"api/";
    public static final String LOGIN_ENDPOINT = BASE_URL + "login";
    public static final String LAYANAN_ENDPOINT = BASE_URL + "layanan";
    public static final String TRANSACTION = BASE_URL + "transaction";
    public static final String DETAIL_TRANSACTION = BASE_URL + "detailTransaction";
    public static final String REGISTER = BASE_URL + "register";
    public static final String BERANDA = BASE_URL + "products";
    public static final String IMAGE_LAYANAN = "img/";
    public static final String RIWAYAT_ENDPOINT = BASE_URL + "pesanan";
    public static final String EditPROFIL_ENDPOINT = BASE_URL + "updateProfil";
    public static final String EDITPASS_ENDPOINT = BASE_URL + "UpdatePasswordController";
    public static final String PESANAN = BASE_URL + "riwayat";
    public static final String UPLOADIMAGE = BASE_URL + "up";
    public static final String METODE_PENGIRIMAN_ENDPOINT = BASE_URL + "metode_pengiriman";

}
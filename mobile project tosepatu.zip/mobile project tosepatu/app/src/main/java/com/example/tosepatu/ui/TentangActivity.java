package com.example.tosepatu.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tosepatu.R;

public class TentangActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tentang_layout
        );
    }
}